const config = require('../config.js')

module.exports = (client) => {
    console.log('Logged In As: ' + client.user.tag)
    console.log('Loading Status')

    const activities_list = [
        `A Message For Status`,
        `Another Message For Status`
    ]
    
        setInterval(() => {
            const index = Math.floor(Math.random() * (activities_list.length - 1) + 1);
            client.user.setActivity(activities_list[index]);
        }, 1500);
        console.log('Status Loaded')
}