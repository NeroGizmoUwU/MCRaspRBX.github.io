const Discord = require('discord.js')
exports.run = async(client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle('Embed Template!!')
    .setDescription('This Is A Embed Template!!!')
    .addField('Template', 'Embed Template')
    .setFooter(`${message.author.tag}`, message.author.displayAvatarURL())
    message.channel.send(embed)
}