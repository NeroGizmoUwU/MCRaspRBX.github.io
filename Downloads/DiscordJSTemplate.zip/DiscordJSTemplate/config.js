const config = {
    token: 'DISCORDAPPTOKEN',
    prefix: 't!'
}